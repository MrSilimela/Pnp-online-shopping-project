# SpringSecurityLoginTutorial

1. mvn clean
2. mvn clean install
3. Go to the target folder
4. java -jar demo-0.0.1-SNAPSHOT.ja

- http://localhost:8080/registration
- http://localhost:8080/login

