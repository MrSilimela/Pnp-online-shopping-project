package com.pnpStore.service;

//import DriverService used files
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pnpStore.model.Driver;
import com.pnpStore.repository.DriverRepository;


//@Services - creates a services bean , has all business logic and calls methods from DriverRepository
@Service
public class DriverService {
	
	//@Autowired - uses properties to get rid of setter methods 
	@Autowired
	public DriverRepository driverRepository;
	
	//gets All Drivers 	
	public List<Driver> getAlldrivers()
	{
		
		List<Driver> drivers = new ArrayList<>();
		driverRepository.findAll()
		.forEach(drivers::add);
		return drivers;
		
	}
	
	//Delete Driver using driver id
	public void DeleteDriver(int driverID) {
		
		
		driverRepository.delete(driverID);
		
	}
	
	//Add Driver
	public void SaveDriver(Driver Drivers) {
		
		
		driverRepository.save(Drivers);
		
	}
	
	//Update Driver using driver id 
	public void updateDriver(int id, Driver Drivers) {
		
		
		driverRepository.save(Drivers);
		
	}
	

}