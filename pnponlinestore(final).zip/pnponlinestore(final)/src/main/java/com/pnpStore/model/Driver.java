package com.pnpStore.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "driver")
public class Driver {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int driver_id;
	private String driver_name;
	private String driver_lastName;
	private String driver_location;
	private int driver_no;
	private String driver_status;	
	public Driver() {
		super();
	}
	public Driver(int driver_id, String driver_name, String driver_lastName, String driver_location, int driver_no,
			String driver_status) {
		super();
		this.driver_id = driver_id;
		this.driver_name = driver_name;
		this.driver_lastName = driver_lastName;
		this.driver_location = driver_location;
		this.driver_no = driver_no;
		this.driver_status = driver_status;
		
	}
	public int getDriver_id() {
		return driver_id;
	}
	public void setDriver_id(int driver_id) {
		this.driver_id = driver_id;
	}
	public String getDriver_name() {
		return driver_name;
	}
	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}
	public String getDriver_lastName() {
		return driver_lastName;
	}
	public void setDriver_lastName(String driver_lastName) {
		this.driver_lastName = driver_lastName;
	}
	public String getDriver_location() {
		return driver_location;
	}
	public void setDriver_location(String driver_location) {
		this.driver_location = driver_location;
	}
	public int getDriver_no() {
		return driver_no;
	}
	public void setDriver_no(int driver_no) {
		this.driver_no = driver_no;
	}
	public String getDriver_status() {
		return driver_status;
	}
	public void setDriver_status(String driver_status) {
		this.driver_status = driver_status;
	}
	
	
	
	

}
