package com.pnpStore.controller;

//import DriverController used files
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pnpStore.service.DriverService;
import com.pnpStore.model.Driver;

//@Controller - indicates that it is a  Spring MVC controller using REST API
@RestController
public class DriverController {
	
	//@Autowired - uses properties to get rid of setter methods
	@Autowired
	private DriverService driverService;
	
	//RequestMapping - maps the specified URL eg '/GetDrivers'
		//RequestMethod = request method type - POST it inserts specific resources
	@RequestMapping("/GetDrivers")
	//Generic array list
	public List<Driver> getAlldrivers() 
	{
		return driverService.getAlldrivers();
	}
	
	//RequestMapping - maps the specified URL eg '/DeleteDriver/{driverID}'
		//RequestMethod = request method type - DELETE it removes specific resources using a certain ID
@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteDriver/{driverID}")
//@PathVariable - identifies the path pattern used in URL for incoming data
	public void DeleteDriver(@PathVariable int driverID)
	{
		driverService.DeleteDriver(driverID);

	}

//RequestMapping - maps the specified URL eg '/SaveDriver'
	//RequestMethod = request method type - POST it inserts specific resources
@RequestMapping(method = RequestMethod.POST,value = "/SaveDriver")
//@RequestBody converts JSON format to java object
public void SaveDriver(@RequestBody Driver Drivers)
{
	driverService.SaveDriver(Drivers);		

}

//RequestMapping - maps the specified URL eg '/UpdateDriver/{id}'
	//RequestMethod = request method type - PUT it updates specific resources using a certain ID
@RequestMapping(method = RequestMethod.PUT,value = "/UpdateDriver/{id}")
//@RequestBody converts JSON format to java object
	//@PathVariable - identifies the path pattern used in URL for incoming data
public void updateDriver(@RequestBody Driver Drivers, @PathVariable int id)
{
	
	driverService.updateDriver(id, Drivers);
	
}
	

}