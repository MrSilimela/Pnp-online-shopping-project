var pnpModule = angular.module("pnpStoreApp",[]);


pnpModule.controller("pnpStoreAppController",function($scope,$http){
	   
    $http.defaults.headers.post["Content-Type"] = "application/json";  
    
	//Get all Drivers in database
	$http.get('http://localhost:8181/GetDrivers').then(function(response){
	console.log(response.data);
	$scope.drivers = response.data; 	
	});
	
	//Get all Deliveries in database
	$http.get('http://localhost:8181/GetDeliveries').then(function(response){
	console.log(response.data);
	$scope.deliveries = response.data; 	
	});
    
    //Get all products in database
    var inventory;
    		$http.get('http://localhost:8181/GetProducts').then(function(response){
    		console.log(response.data);
    		$scope.products = response.data;   		
    		
    		});
    		
    		 //Get all inventory in database
    		$http.get('http://localhost:8181/GetInventories').then(function(response){
    		console.log(response.data);
    		$scope.inventories = response.data; 	
    		});
    		
    		//Get user by email
    		$http.get('http://localhost:8181/user').then(function successCallback(response) {
    		$scope.userEmail=response.data;	
    		console.log()
    		}, function errorCallback(response) {
    		//console.log(response.statusText);
    		});
    		
    		//Get user by email
    		$http.get('http://localhost:8181/viewUser').then(function successCallback(response) {
    		$scope.userDetails=response.data;
    		var name = $scope.userDetails[0].id;
    		//View cart products
    		console.log(name);
    		
    		
    		$http.get('http://localhost:8181/viewCart/' + name ).then(function successCallback(response) {
    		$scope.cart=response.data;
    		
    		var totalAmt = 0;
			
			 for (var x = 0; x < $scope.cart.length ; x++)
				 { 
				 	totalAmt = totalAmt + $scope.cart[x].cart_price;
			     };
				 $scope.totalAmount = totalAmt ;
		
    		});
    		});
    		
    		//Add to cart in database
    		 $scope.create = function (prod,quant)
	         {
	            var Add2Cart = {
	            "product_name": prod.product_name,
	        	"cart_quantity" : quant ,
	        	"cart_price": prod.product_price * quant,
	        	"product_id": prod.product_id,
	        	"user_id" : $scope.userDetails[0].id,
	        	"order_no" : null,
	        	"product_img" :  prod.product_img 
	         };
	            
	            console.log(Add2Cart);
	            
	       $http.post('http://localhost:8181/SaveCart',Add2Cart).then(function(response){
             console.log(response);
             if(response.data.getcart_id !== 0)
             {
                       console.log("Cart product...");
                       alert("Cart product Added...");
                       location.reload(true);
                       
             }else{
                       console.log("Cart product Not Added");
                       alert("Cart product Not Added...");
                       location.reload(true);
                  }
             });
                
            };
            
            
            //Delete cart item
            $scope.DeleteItem = function (name)
            {
                var ID = name.cart_id;
                console.log(ID);
                  $http.delete('http://localhost:8181/DeleteCart/' +ID).then(function(response){
                    console.log(response);
                    if(response.data !== 0)
                    {
                       
                        alert("Item has been Deleted");
                        location.reload(true);
                    }else{
                       
                        alert("Item Not Deleted..!!!");
                        location.reload(true);
                    }
                });
            };
            //validate payment
            $scope.validatePay = function (banks,type,cardNo)
            {
            	
            	var bank = $scope.banks;
            	$scope.banks = bank;
            	var cardNo = $scope.cardNo;
            	$scope.cardNo = cardNo;
            	var type = $scope.type;
            	$scope.type = type;
            	
            	if(bank !== undefined && type !== undefined && cardNo > "999999999999999" && cardNo < "9999999999999999")
            		{
            			alert("Payment successfully proccessed");
            			$("#myModal").modal('hide');
            			$("#myModal2").modal('show');
            			
            		
            		}
            	else { alert("Payment unsuccessfully");
            	     $("#myModal2").modal('hide');
            	        //location.reload(true);
            	}            	
            	
            	
            };
            
            //Cancel redirect
            $scope.Cancel = function ()
            {
            	
            	location.reload(true);
            };
      
            //validate order details
            $scope.order = function ()
            {
            	alert("order successfully proccessed");
            
            }

            
          //Get all orders in database
    		$http.get('http://localhost:8181/GetOrders').then(function(response){
    		console.log(response.data);
    		$scope.orders = response.data; 	
    		});
    		
    		//Insert orders in database
    		 $scope.order = function (contactNo,address,location)
	         {
    			 var contactNo = $scope.contactNo;
             	$scope.contactNo = contactNo;
             	var address = $scope.address;
             	$scope.address = address;
             	var location = $scope.location;
             	$scope.location = location;
    			var userID = $scope.userDetails[0].id; 
	            var Add2Order = {
	            "userNo": contactNo,
	        	"user_address" : address ,
	        	"user_location": location,
	        	"user_id" : $scope.userDetails[0].id,
	         };
	            
	            console.log(Add2Order);
	            var user_id; var order_id;
	       $http.post('http://localhost:8181/InsertOrders',Add2Order).then(function(response){                        
             if(response.data.getorder_id !== 0){	            	 
            	
            	    $http.get('http://localhost:8181/GetOrders').then(function(response){
             		console.log(response.data);
             		$scope.orders = response.data;
             		console.log($scope.orders.length);
             		console.log(response.data[$scope.orders.length -1]);
             		order_id = response.data[$scope.orders.length -1].order_id;
             		user_id = response.data[$scope.orders.length -1].user_id;             		
             		});
                 //get all carts
                $http.get('http://localhost:8181/GetCarts').then(function(response){             	
             		$scope.carts = response.data;            	
             		 $scope.carts = response.data;
                     console.log(response.data.length);
                       var cartLegth = $scope.carts.length;
                       
                       
                       	for(var i=0; i<cartLegth; i++)
                       		{		var CartUserID =$scope.carts[i].user_id;
                       				var CartID =$scope.carts[i].cart_id;
                       				var product_name =$scope.carts[i].product_name;
                       				var cart_price =$scope.carts[i].cart_price;
                       				var cart_quantity =$scope.carts[i].cart_quantity;
                       				var product_id =$scope.carts[i].product_id;
                       				var product_img =$scope.carts[i].product_img;
                       		if(CartUserID == user_id)
                       		
                       		{	
                       		 	var UpdateCart = {
                       	    		 "cart_id" : CartID,
                       	        	"order_no" : order_id,
                       	        	"user_id" : CartUserID,
                       	        	"cart_price" : cart_price,
                       	        	"cart_quantity" : cart_quantity,
                       	        	"product_name" : product_name,
                       	        	"product_id" : product_id,
                       	        	"product_img" : product_img,
                       	        	
                       	              };
                       		 	
                       		  $http.put('http://localhost:8181/UpdateCart/'+ CartID,UpdateCart).then(function(response)
                            		   {
                            	   			//Inserting to deliveries
                       			         //Getting delivery date and time
                       			var Mydate = new Date();       
                       		    var hh = Mydate.getHours();
                       		    var mn = Mydate.getMinutes();
                       		    var mm = Mydate.getMonth() +1;
                       		    var yy = Mydate.getFullYear();
                       		    var dd = Mydate.getDate();
                       		    if(dd < 10) { dd = '0'+dd;}
                       		    if(mm < 10) {mm = '0'+mm;}
                       		    if(mm < 1) {mm = '0'+1;}
                       		     var deliveryDate = dd + '/' + mm + '/' + yy;
                       		    if(mn<10) { mn = '0'+mn;}
                       		    var deliveryTime = hh + ':' + mn;
                       		    console.log(deliveryTime);
                       		    console.log(deliveryDate);
                       			         var status = "pending";
                       			        var Add2Delivery = {                          	    		
                          	        	"order_id" : order_id,
                          	        	"delivery_date" : deliveryDate,
                          	        	"delivery_time" : deliveryTime,
                          	        	"delivery_status" : status,
                          	        
                          	              };
                            	   $http.post('http://localhost:8181/SaveDelivery',Add2Delivery).then(function(response){
                            	   
                            		   if(response.data.getdelivery_id !== 0){
                                       alert("your delivery has been Added...");
                                       
                                       
                             }else{
                                       console.log("delivery Not Added");
                                       alert("your order has not been Added......");
                                       location.reload(true);
                                  }
                            		   
                            	   });                           	
                            	     
                            	     });
                       		}
                       	}
             		
             		});
               
            	   
                       alert("your order has been Added...");
                       
                       
             }else{
                       console.log("Order Not Added");
                       alert("your order has not been Added......");
                       location.reload(true);
                  }
             });
                
            };
            
          //Get all orders in database
    		$http.get('http://localhost:8181/GetOrders').then(function(response){
    		console.log(response.data);
    		$scope.orders = response.data; 	
    		});
    		
    		//Get all Users in database
    		$http.get('http://localhost:8181/GetUsers').then(function(response){
    		console.log(response.data);
    		$scope.users = response.data; 	
    		});
    		
    	    //Delete product in database
            $scope.DeleteProduct = function (prod)
            {
                var ID = prod.product_id;
                console.log(ID);
                  $http.delete('http://localhost:8181//DeleteProduct/' +ID).then(function(response){
                    console.log(response);
                    if(response.data !== 0)
                    {
                       
                        alert("Product has been Deleted");
                        location.reload(true);
                    }else{
                       
                        alert("Product Not Deleted..!!!");
                        location.reload(true);
                    }
                });
            };
            
            //Add product to database           
            $scope.AddProduct = function (group,productName,productPrice,productQuantity)
	         {
            	var file = document.getElementById('img');
       		 	var name = "/images/products/" + file.files.item(0).name;
   			    var group = $scope.group;
            	$scope.group = group;
            	var productName = $scope.productName;
            	$scope.productName = productName;            	
            	var productPrice = $scope.productPrice;
            	$scope.productPrice = productPrice;
            	var productQuantity = $scope.productQuantity;
            	$scope.productQuantity = productQuantity;
            
   			 
	            var Add2Product = {
	            "product_name": productName,
	        	"product_group" : group ,
	        	"product_price": productPrice,
	        	"product_img" : name,
	         };
	            
	            
	            
	            console.log(name);
	            
	       $http.post('http://localhost:8181/SaveProduct',Add2Product).then(function(response){
            console.log(response);
            if(response.data.getproduct_id !== 0)
            {
                      console.log(response.config.data.getproduct_id);
                      alert("Product has been Added...");
                      var Add2Invetory = {
      	    	            "product_name": productName,      	    	        	
      	    	        	"product_quantity": productQuantity,
      	    	        	     	    	        	
      	    	         };
                      $http.post('http://localhost:8181/SaveInventory',Add2Invetory).then(function(response){
                          console.log(response);
                          if(response.data.getinvetory_id !== 0)
                          {  alert("Invetory has been Added...");    }
                          else{alert("Invetory has not been Added......");}
                      });
                      location.reload(true);
                      
            }else{
                      console.log("Product Not Added");
                      alert("Product has not been Added......");
                      location.reload(true);
                 }
            });
               
           };
           
           //Update product
           $scope.prod2Updates; var prod_id;
           $scope.UpdatProduct = function (prod)
           {
               var ID = prod.product_id;
               prod_id = ID;
               var product_name = prod.product_name;
               var product_price = prod.product_price;
               var product_img = prod.product_img;
               var product_group = prod.product_group;
                var prod2Update =[{"product_name":product_name,"product_img": product_img,"product_price": product_price, "product_group": product_group,"ID":ID}];
               
               console.log(product_name);
               console.log(prod2Update);     
               if(ID != null){               
               $scope.prod2Updates = prod2Update;
   			    $("#UpdateProducts").modal('show');  		
   		
               }
               else {location.reload(true);}          
           };
           //update product and add to database
           $scope.UpdateProd = function (group,productName,productPrice,prod2Update)
           {           
        	   var prodID = prod_id;
        	   var file = document.getElementById('img2');
  		 	   var name = "/images/products/" + file.files.item(0).name;
  		 	   var group = $scope.group;
         	   $scope.group = group;
         	  var productName = $scope.productName;
         	  $scope.productName = productName;            	
         	  var productPrice = $scope.productPrice;
         	  $scope.productPrice = productPrice;
         	 console.log(prodID);
         	 
         	   var prodData = {
       	            "product_name": productName,
       	        	"product_group" : group ,
       	        	"product_price": productPrice,
       	        	"product_img" : name,
       	        	"product_id" : prodID,
       	         };
         	
         	  $http.put('http://localhost:8181/UpdateProduct/'+ prodID,prodData).then(function(response){
                  console.log(response);
                  if(response.data.getproduct_id !== 0)
                  {
                            console.log(response);
                            alert("Product has been updated...");
                            location.reload(true);
                            
                  }else{
                            console.log("Product Not Added");
                            alert("Product has not been updated......");
                            location.reload(true);
                       }
                  });
           };
         	 //delete user
         	 $scope.deleteUser = function (user)
             {           
          	  var User_id = user.id
           	  var user_name = user.name;
          	 var last_Name = user.lastName;            	
           	  var active = user.active;
           	var email = user.email;
           	var password = user.password;
           	var roles = user.roles;
           	var roles2 = "0";
           	  
           	 
           	 
           	   var UserData = {
         	             "id": User_id,
         	            "email" : email,
         	        	"password": password,
         	        	"name" : user_name,
         	        	"lastName" : last_Name,
         	        	"active" : active,
         	        	"roles" : null,
         	        	
         	         };
           	console.log(UserData);
           	 $http.put('http://localhost:8181/UpdateUser/'+ User_id,UserData).then(function(response){
                    console.log(response);
                    if(response.data.getid !== 0)
                    {
                    	  $http.delete('http://localhost:8181//DeleteUser/' + User_id).then(function(response){
                              console.log(response);
                              if(response.data !== 0)
                              {
                                 
                                  alert("User has been Deleted");
                                  location.reload(true);
                              }else{
                                 
                                  alert("User Not Deleted..!!!");
                                  location.reload(true);
                              }
                          });
                              
                              
                    }else{
                              
                              alert("User Not Deleted..!!!");
                              location.reload(true);
                         }
                    });
             };
         	
             //Delete order
             $scope.DeleteOrder = function (order)
             {   
                 var ID = order.order_id;
                 console.log(ID);
                   $http.delete('http://localhost:8181//DeleteOrder/' +ID).then(function(response){
                     console.log(response);
                     if(response.data !== 0)
                     {
                        
                         alert("Order has been Deleted");
                         location.reload(true);
                     }else{
                        
                         alert("Order Not Deleted..!!!");
                         location.reload(true);
                     }
                 });
             };
             
             //Adding new driver
             $scope.AddDriver = function (name,lastName,DriverNumber)
	         {
            	
   			    var name = $scope.name;
            	$scope.name = name;
            	var lastName = $scope.lastName;
            	$scope.lastName = lastName;            	
            	var DriverNumber = $scope.DriverNumber;
            	$scope.DriverNumber = DriverNumber;
            	var location = "Not available";
            	var status = "Off duty";
            
   			 
	            var Add2Driver = {	            
	        	"driver_lastName" : lastName,
	        	"driver_name": name,
	        	"driver_no" : DriverNumber,
	        	"driver_status" : status,
	        	"driver_location" : location,
	         };
	            
	            console.log(Add2Driver);
	            
	            $http.post('http://localhost:8181/SaveDriver',Add2Driver).then(function(response){
	            	console.log(response);
	            	if(response.data.getdriver_id !== 0)
	            	{
                      console.log(response);
                      alert(name + "has been Added...");
                      $("#AddDriver").modal('hide');
                      $("#AddProducts").modal('hide');
                      $("#UpdateProducts").modal('hide');
                      location.reload();
                      
	            	}else{
                      console.log("driver Not Added");
                      alert("driver has not been Added......");
                      location.reload(true);
                 }
            });
               
           };
           
           //Delete driver
           $scope.DeleteDriver = function (driver)
           {   
               var ID = driver.driver_id;
               
                 $http.delete('http://localhost:8181//DeleteDriver/' +ID).then(function(response){
                   console.log(response);
                   if(response.data !== 0)
                   {
                      
                       alert("Driver has been Deleted");
                       location.reload(true);
                   }else{
                      
                       alert("Driver Not Deleted..!!!");
                       location.reload(true);
                   }
               });
           };
           
           
           //Update product
           var drv2Updates; var drvr_id; var driver_status2; var driver_location2;var orderNo; var deliveryID;
           $scope.UpdateDriver = function (driver)
           {
               var ID = driver.driver_id;
               drvr_id = ID;
               var driver_name = driver.driver_name;
               var driver_lastName = driver.driver_lastName;
               var driver_no = driver.driver_no;
               var driver_location = driver.driver_location;
               var d_status = driver.status;
                var drv2Update =[{"driver_name":driver_name,"driver_lastName": driver_lastName,"driver_no": driver_no, "d_status": d_status, "driver_location": driver_location,"ID":ID}];
                   
               if(ID != null){               
               $scope.drv2Updates = drv2Update;
   			    $("#UpdateStatus").modal('show');  		
   		
               }
               else {location.reload(true);}          
           };
           //Update driver status
           $scope.UpdateDriverStatus = function (status,location,name,lastName,DriverNumber)
           {           
        	   var Drvr_id = drvr_id;        	   
  		 	   var status = $scope.status;
         	   $scope.status = status;
         	  var location = $scope.location;
         	  $scope.location = location; 
         	 var name = $scope.name;
        	  $scope.name = name;
        	  var lastName = $scope.lastName;
        	  $scope.lastName = lastName;
        	  var DriverNumber = $scope.DriverNumber;
        	  $scope.DriverNumber = DriverNumber;
        	  driver_location2 = location;
        	  driver_status2 = status;
        	  
         	
         	 
         	   var driverData = {
         			"driver_id" : Drvr_id,
       	            "driver_name": name,
       	        	"driver_lastName" : lastName ,
       	        	"driver_no": DriverNumber,
       	        	"driver_status" : status,
       	        	"driver_location" : location,
       	         };
         	
         	  $http.put('http://localhost:8181/UpdateDriver/'+ Drvr_id,driverData).then(function(response){
                  console.log(response);
                  if(response.data.getdriver_id !== 0)
                  {
                            console.log(response);
                            alert("Driver has been updated...");
                            $("#UpdateStatus").modal('hide');
                            
                            
                          //Get all Orders in database
                        	$http.get('http://localhost:8181/GetOrders').then(function(response){
                        	console.log(response.data);
                        	$scope.orders = response.data; 
                        	var statusString = "On duty";
                        	var statusString3 = "Done";
                        	
                        		for(var i=0; i<response.data.length; i++)
                        			{
                        			if(driver_status2 == statusString && driver_location2 == response.data[i].user_location)
                            		{
                        				orderNo = response.data[i].order_id;
                        				//Get all Deliveries in database
                        				$http.get('http://localhost:8181/GetDeliveries').then(function(response){
                        				console.log(response.data);
                        				$scope.deliveries = response.data;
                        				for(var j=0; j<response.data.length; j++)
                            			{	 var deliveryString5 = "pending";
                        					if(orderNo == response.data[j].order_id && deliveryString5 == response.data[j].delivery_status)
                        						{	deliveryID = response.data[j].delivery_id;
                        							var deliveryString = "On its way";
                        				    	   var deliveryData = {
                        				       	            "delivery_id": response.data[j].delivery_id,
                        				       	        	"order_id" : response.data[j].order_id ,
                        				       	        	"delivery_date": response.data[j].delivery_date,
                        				       	        	"delivery_time" : response.data[j].delivery_time,
                        				       	        	"delivery_status" : deliveryString,
                        				       	         };
                        				         	
                        				         	  $http.put('http://localhost:8181/UpdateDelivery/'+ deliveryID,deliveryData).then(function(response){
                        				                  console.log(response);
                        				                  if(response.data.getdelivery_id !== 0)
                        				                  {
                        				                            console.log(response);
                        				                            alert("delivery has been updated...");
                        				                            location.reload(true);
                        				                            
                        				                  }else{
                        				                            console.log("delivery Not Added");
                        				                            alert("delivery has not been updated......");
                        				                            location.reload(true);
                        				                       }
                        				                  });
                        						
                        						}
                            			}
                        				
                        				});
                        				
                        			}
                        			//If for compling delivery
                        			else if(driver_status2 == statusString3 && driver_location2 == response.data[i].user_location)
                            		{
                        				orderNo = response.data[i].order_id;
                        				//Get all Deliveries in database
                        				$http.get('http://localhost:8181/GetDeliveries').then(function(response){
                        				console.log(response.data);
                        				$scope.deliveries = response.data;                        			
                        				for(var j=0; j<response.data.length; j++)
                            			{   var deliveryString4 = "On its way";
                            			   console.log(response.data);
                        					if(orderNo == response.data[j].order_id && deliveryString4 == response.data[j].delivery_status)
                        						{	deliveryID = response.data[j].delivery_id;
                        							var deliveryString3 = "Delivered";
                        				    	   var deliveryData = {
                        				       	            "delivery_id": response.data[j].delivery_id,
                        				       	        	"order_id" : response.data[j].order_id ,
                        				       	        	"delivery_date": response.data[j].delivery_date,
                        				       	        	"delivery_time" : response.data[j].delivery_time,
                        				       	        	"delivery_status" : deliveryString3,
                        				       	         };
                        				         	
                        				         	  $http.put('http://localhost:8181/UpdateDelivery/'+ deliveryID,deliveryData).then(function(response){
                        				                  console.log(response);
                        				                  if(response.data.getdelivery_id !== 0)
                        				                  {
                        				                            console.log(response);
                        				                            alert("delivery has been successfull...");
                        				                            location.reload(true);
                        				                            
                        				                  }else{
                        				                            console.log("delivery Not Added");
                        				                            alert("delivery has not been unsuccessfull......");
                        				                            location.reload(true);
                        				                       }
                        				                  });
                        						
                        						}
                            			}
                        				
                        				});
                        				
                        			}
                        			
                        			
                        			
                        		
                        		}
                        	
                        	
                        	});
                            
                            
                  }else{
                            console.log("Driver Not Added");
                            alert("Driver has not been updated......");
                            location.reload(true);
                       }
                  });
           };
           
           //Clearing cart
        var cartID; var orderID; var cartProductName; var cartQntity; var inventoryID; var inventoryQntity;
       	$http.get('http://localhost:8181/GetDeliveries').then(function(response){
       	console.log(response.data);
       	$scope.deliveries = response.data;
       	for(var j=0; j<response.data.length; j++)
		{	 var DeliveryState = "Delivered";
				if(DeliveryState == response.data[j].delivery_status){
					orderID = response.data[j].order_id;
					
					$http.get('http://localhost:8181/GetCarts').then(function(response){
				       	console.log(response.data);
				       	$scope.carts = response.data;
				       	for(var i=0; i<response.data.length; i++)
				       		{
				       			if(orderID == response.data[i].order_no){
				       				cartID = response.data[i].cart_id;
				       				cartQntity = response.data[i].cart_quantity;
				       				cartProductName = response.data[i].product_name;
				       				$http.get('http://localhost:8181/GetInventories').then(function(response){
				       					console.log(response.data);
								       	$scope.inventories = response.data;
								       	for(var x=0; x<response.data.length; x++)
								       		{
								       			if(cartProductName == response.data[x].product_name)
								       				{ inventoryID = response.data[x].inventory_id;
								       				inventoryQntity = response.data[x].product_quantity - cartQntity;
								       				var UpdateInventory = {
						                       	    		 "inventory_id" : response.data[x].inventory_id,
						                       	        	"product_quantity" : inventoryQntity,
						                       	        	"product_name" : response.data[x].product_name,
								       				};
								       				$http.put('http://localhost:8181/UpdateInventory/'+ inventoryID,UpdateInventory).then(function(response)
						                            		   {
						                                         if(response.data.getinventory_id !== 0){
						                                       alert("Inventory has been updated...");
						                                       
						                                       
						                             }else{
						                                       console.log("Inventory Not updated");
						                                       alert("Inventory has not been updated......");
						                                       location.reload(true);
						                                  }
						                                   
						                                   
						                                   });
								       				
								       				}
								       		}
				       					
				       					
				       			 });
				       				
				       		      $http.delete('http://localhost:8181//DeleteCart/' +cartID).then(function(response){
				                      console.log(response);
				                      if(response.data !== 0)
				                      {
				                         
				                          alert("Cart has been Deleted");
				                          location.reload(true);
				                      }else{
				                         
				                          alert("Cart Not Deleted..!!!");
				                          location.reload(true);
				                      }
				                  });
				       				
				       			}
				       		}
					
					}); 
				}
       		
		}
       	
       	}); 
             
});



